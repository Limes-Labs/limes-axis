"""A public context reader; host authorization and private overlays stay in Axis."""

from __future__ import annotations

import re
from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass
from typing import Protocol

from .client import GovCoreContractError, parse_entity


class PublicEntityClient(Protocol):
    def get_entity(self, gov_entity_id: str) -> dict[str, object]: ...


@dataclass(frozen=True)
class AxisPublicContext:
    namespace: str
    entity: dict[str, object]


class AxisPublicContextReader:
    def __init__(
        self,
        client: PublicEntityClient,
        *,
        authorize: Callable[[str, str], bool],
    ) -> None:
        self._client = client
        self._authorize = authorize

    def get_entity_context(self, tenant_key: str, gov_entity_id: str) -> AxisPublicContext:
        """Run the local host gate, then send only the public entity ID to GovCore.

        The callback must bind the verified host principal, tenant admission and
        applicable permission policy on every invocation, before and after HTTP.
        No transaction or lock should be held during the remote read. A returned context is evidence, never a
        grant to read private records, invoke a model or execute an action.
        """
        if (
            not isinstance(tenant_key, str)
            or not tenant_key.strip()
            or not isinstance(gov_entity_id, str)
            or not re.fullmatch(r"gov_[0-9a-f]{32}", gov_entity_id)
        ):
            raise ValueError("local tenant and canonical public entity ID are required")
        if self._authorize(tenant_key, gov_entity_id) is not True:
            raise PermissionError("host authorization denied public context read")
        entity = deepcopy(parse_entity(self._client.get_entity(gov_entity_id)))
        if entity["id"] != gov_entity_id or entity["status"] != "active":
            raise GovCoreContractError("public context response identity or lifecycle mismatch")
        # Read the current host state again: a remote read cannot preserve a
        # grant revoked while the network call was in flight.
        if self._authorize(tenant_key, gov_entity_id) is not True:
            raise PermissionError("host authorization denied public context read")
        return AxisPublicContext(namespace="public_institutional", entity=entity)
