# SPDX-License-Identifier: MIT
# Copyright (c) 2026 metaforismo
"""Strict single-page discovery snapshots, not current category authorization."""

import re
from typing import cast

from .client import (
    _choice,
    _date,
    _fail,
    _id,
    _interval,
    _list,
    _provenance,
    _record,
    _text,
    _url,
    parse_entity,
)
from .types import CoverageSnapshot, Page

KINDS = {"country", "region", "province", "municipality", "organization", "office"}
CONTACT_STATES = {"listed", "pending", "verified", "revoked", "suspended"}
SOURCE_STATES = {"active", "revoked", "suspended"}
CATEGORIES = {"road_maintenance", "street_lighting", "waste", "public_green", "road_signage"}
MAX_SAFE_INTEGER = 2**53 - 1


def count(value, maximum=MAX_SAFE_INTEGER) -> int:
    if type(value) is not int or not 0 <= value <= maximum:
        _fail()
    return value


def page_parameters(limit: int, offset: int) -> dict[str, str]:
    if (
        type(limit) is not int
        or not 1 <= limit <= 100
        or type(offset) is not int
        or not 0 <= offset <= 100000
    ):
        raise ValueError("Public page requires limit 1..100 and offset 0..100000")
    return {"limit": str(limit), "offset": str(offset)}


def relationship(value, entity_id):
    r = _record(value, {"subject_id", "relation", "object_id", "valid_from", "valid_to", "provenance"})
    _choice(r["relation"], {"LOCATED_IN", "PART_OF", "SUCCESSOR_OF"})
    if _id(r["subject_id"]) != entity_id:
        _fail()
    _id(r["object_id"])
    _interval(r["valid_from"], r["valid_to"])
    _provenance(r["provenance"])
    return r


def contact(value, entity_id):
    c = _record(
        value,
        {
            "id",
            "entity_id",
            "office_id",
            "kind",
            "target",
            "label",
            "competences",
            "conditions",
            "verification_status",
            "verified_at",
            "review_due_at",
            "valid_from",
            "valid_to",
            "provenance",
        },
    )
    if (
        not re.fullmatch(r"contact_[a-z0-9_-]{1,128}", _text(c["id"], 136))
        or _id(c["entity_id"]) != entity_id
    ):
        _fail()
    if c["office_id"] is not None:
        _id(c["office_id"])
    _choice(c["kind"], {"email", "pec", "web_form", "phone"})
    _text(c["target"])
    _text(c["label"], 300)
    if c["kind"] in {"email", "pec"} and not re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", c["target"]):
        _fail()
    if c["kind"] == "web_form":
        _url(c["target"])
    competences = _list(c["competences"], 5)
    for category in competences:
        _choice(category, CATEGORIES)
    if len(set(competences)) != len(competences):
        _fail()
    for condition in _list(c["conditions"], 10):
        if condition != "":
            _text(condition, 500)
    _choice(c["verification_status"], CONTACT_STATES)
    verified, due = _date(c["verified_at"]), _date(c["review_due_at"])
    _interval(c["valid_from"], c["valid_to"])
    _provenance(c["provenance"])
    if c["verification_status"] == "verified":
        supported = {
            category
            for e in c["provenance"]
            if e["scope"] == "reporting_channel" and e["verification_status"] == "verified"
            for category in e["competences"]
        }
        if not verified or not due or due <= verified or not competences or not set(competences) <= supported:
            _fail()
    # Historical review expiry and revoked/suspended/listed states remain visible.
    return c


def source(value):
    s = _record(
        value,
        {
            "id",
            "name",
            "owner",
            "url",
            "kind",
            "allowed_hosts",
            "license",
            "license_url",
            "attribution",
            "status",
            "refresh_days",
            "last_retrieved_at",
        },
    )
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,127}", _text(s["id"], 128)):
        _fail()
    for key in ("name", "owner", "license"):
        _text(s[key], 300)
    _text(s["attribution"], 1000)
    _url(s["url"])
    _choice(s["kind"], {"official_dataset", "official_service", "official_page"})
    hosts = _list(s["allowed_hosts"], 20)
    if not hosts:
        _fail()
    for host in hosts:
        if not re.fullmatch(r"[a-z0-9][a-z0-9.-]*", _text(host, 253)):
            _fail()
    if s["license_url"] not in (None, ""):
        _url(s["license_url"])
    _choice(s["status"], SOURCE_STATES)
    if not 1 <= count(s["refresh_days"], 3650):
        _fail()
    _date(s["last_retrieved_at"])
    return s


def gap(value):
    item = _record(value, {"id", "name", "istat_code"})
    _id(item["id"])
    _text(item["name"], 300)
    if item["istat_code"] is not None and not re.fullmatch(r"[0-9]{6}", _text(item["istat_code"], 6)):
        _fail()
    return item


def parse_page(value, kind, *, limit, offset, entity_id=None) -> Page:
    p = _record(value, {"schema_version", "items", "total", "limit", "offset"})
    if p["schema_version"] != "1" or count(p["limit"], 100) != limit or count(p["offset"], 100000) != offset:
        _fail()
    total = count(p["total"])
    items = _list(p["items"], limit)
    if len(items) != min(limit, max(total - offset, 0)):
        _fail()
    parsers = {
        "relationships": lambda v: relationship(v, entity_id),
        "offices": parse_entity,
        "contacts": lambda v: contact(v, entity_id),
        "sources": source,
        "municipal_ipa_gap": gap,
    }
    parsed = [parsers[kind](item) for item in items]
    if kind == "offices" and any(item["kind"] != "office" for item in parsed):
        _fail()
    if kind != "relationships":
        ids = [item["id"] for item in parsed]
        if len(set(ids)) != len(ids):
            _fail()
    # Preserve SQL server order; collation/office tie-breakers are not portable.
    # Pages do not share a snapshot or continuation token.
    return cast(Page, {**p, "items": parsed})


def parse_coverage(value) -> CoverageSnapshot:
    c = _record(value, {"schema_version", "as_of", "scope", "entities", "identifiers", "contacts", "sources"})
    if c["schema_version"] != "1" or c["scope"] != "registered_public_records" or _date(c["as_of"]) is None:
        _fail()
    entities = _record(c["entities"], {"total", "active", "by_kind"})
    kinds = _record(entities["by_kind"], KINDS)
    total = count(entities["total"])
    active = count(entities["active"])
    if active > total or sum(count(v) for v in kinds.values()) != total:
        _fail()
    identifiers = _record(
        c["identifiers"],
        {
            "total",
            "active_municipalities_with_current_istat",
            "active_municipalities_with_current_istat_and_ipa",
        },
    )
    identity_total = count(identifiers["total"])
    istat = count(identifiers["active_municipalities_with_current_istat"])
    both = count(identifiers["active_municipalities_with_current_istat_and_ipa"])
    if both > istat or istat > min(active, kinds["municipality"], identity_total):
        _fail()
    contacts = _record(c["contacts"], {"total", "by_status", "stored_verified_reviews_due"})
    states = _record(contacts["by_status"], CONTACT_STATES)
    if (
        sum(count(v) for v in states.values()) != count(contacts["total"])
        or count(contacts["stored_verified_reviews_due"]) > states["verified"]
    ):
        _fail()
    sources = _record(
        c["sources"], {"total", "by_status", "never_acquired", "active_refresh_due", "latest_retrieval"}
    )
    states = _record(sources["by_status"], SOURCE_STATES)
    total = count(sources["total"])
    if (
        sum(count(v) for v in states.values()) != total
        or count(sources["never_acquired"]) > total
        or count(sources["active_refresh_due"]) > states["active"]
    ):
        _fail()
    latest = _date(sources["latest_retrieval"])
    if (latest is None) != (sources["never_acquired"] == total):
        _fail()
    return cast(CoverageSnapshot, c)
