"""Civlo's optional public identity lookup; no private profile interface."""

from __future__ import annotations

from .client import GovCoreClient, GovCoreContractError


def lookup_civlo_entity(
    client: GovCoreClient,
    *,
    is_municipality: bool,
    istat_code: str | None = None,
    ipa_code: str | None = None,
) -> dict[str, object]:
    """Resolve exact public keys together; the host owns authorization/persistence."""
    if type(is_municipality) is not bool:
        raise ValueError("Explicit institutional type required")
    if is_municipality and not istat_code:
        raise ValueError("Municipal authority requires its own ISTAT code")
    if not is_municipality and (istat_code is not None or not ipa_code):
        raise ValueError("Nonmunicipal authority requires IPA without headquarters ISTAT")
    result = client.resolve(istat_code=istat_code, ipa_code=ipa_code)
    if result["status"] == "resolved":
        entity = result["entity"]
        if (entity["kind"] == "municipality") is not is_municipality:
            raise GovCoreContractError("Resolved institutional type does not match the public identity")
    return result
