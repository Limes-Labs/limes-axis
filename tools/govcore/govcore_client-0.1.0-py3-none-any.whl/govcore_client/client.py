"""Public institutional identifiers only; no product state or administrator writes."""

from __future__ import annotations

import json
import re
import time
from datetime import UTC, datetime
from urllib.parse import urlsplit

import httpx


class GovCoreUnavailable(RuntimeError):
    pass


class GovCoreContractError(ValueError):
    pass


GOV_ID = re.compile(r"gov_[0-9a-f]{32}")
PATTERNS = {
    "istat": r"[0-9]{6}",
    "ipa": r"[A-Za-z0-9_-]{1,64}",
    "tax_code": r"[0-9]{11}",
    "istat_region": r"[0-9]{2}",
    "istat_province": r"[0-9]{3}",
}
PREDICATES = {
    "website",
    "population",
    "population_year",
    "mountain_classification",
    "internal_area_classification",
    "province_capital",
    "territorial_classification",
}


def _fail() -> None:
    raise GovCoreContractError("Invalid public GovCore response")


def _record(value, allowed: set[str], required: set[str] | None = None) -> dict:
    if not isinstance(value, dict) or set(value) - allowed or not (required or allowed) <= set(value):
        _fail()
    return value


def _text(value, limit=2048) -> str:
    if not isinstance(value, str) or not 1 <= len(value) <= limit or re.search(r"[\x00-\x1f\x7f]", value):
        _fail()
    return value


def _id(value) -> str:
    if not isinstance(value, str) or not GOV_ID.fullmatch(value):
        _fail()
    return value


def _choice(value, choices) -> str:
    if not isinstance(value, str) or value not in choices:
        _fail()
    return value


def _interval(start, end) -> None:
    start, end = _date(start), _date(end)
    if start and end and end <= start:
        _fail()


def _current(start, end, at: datetime) -> bool:
    start, end = _date(start), _date(end)
    return (start is None or start <= at) and (end is None or at < end)


def _date(value) -> datetime | None:
    if value is None:
        return None
    try:
        parsed = datetime.fromisoformat(_text(value, 60).replace("Z", "+00:00"))
    except ValueError:
        _fail()
    if parsed.tzinfo is None:
        _fail()
    return parsed


def _url(value) -> str:
    value = _text(value)
    try:
        url = urlsplit(value)
    except ValueError:
        _fail()
    if (
        url.scheme not in {"http", "https"}
        or not url.hostname
        or url.username
        or url.password
        or url.fragment
        or re.search(r"(?:token|key|password|secret)=", url.query, re.I)
    ):
        _fail()
    return value


def _list(value, maximum) -> list:
    if not isinstance(value, list) or len(value) > maximum:
        _fail()
    return value


def _json_object(pairs) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            _fail()
        result[key] = value
    return result


def _provenance(value) -> None:
    if not _list(value, 20):
        _fail()
    for item in value:
        e = _record(
            item,
            {
                "source_id",
                "source_url",
                "retrieved_at",
                "content_sha256",
                "verified_at",
                "verification_status",
                "valid_from",
                "valid_to",
                "scope",
                "competences",
            },
        )
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,127}", _text(e["source_id"], 128)) or not re.fullmatch(
            r"[0-9a-f]{64}", _text(e["content_sha256"], 64)
        ):
            _fail()
        _url(e["source_url"])
        retrieved, verified = _date(e["retrieved_at"]), _date(e["verified_at"])
        if retrieved is None or retrieved > datetime.now(UTC) or (verified and verified > datetime.now(UTC)):
            _fail()
        _choice(e["verification_status"], {"observed", "verified"})
        if e["verification_status"] == "verified" and (verified is None or verified < retrieved):
            _fail()
        _interval(e["valid_from"], e["valid_to"])
        _choice(e["scope"], {"institutional", "contact_listing", "reporting_channel"})
        competence = _list(e["competences"], 5)
        for c in competence:
            _choice(c, {"road_maintenance", "street_lighting", "waste", "public_green", "road_signage"})
        if e["scope"] != "reporting_channel" and competence:
            _fail()


def parse_entity(value) -> dict[str, object]:
    e = _record(
        value,
        {"schema_version", "id", "kind", "name", "status", "provenance", "identifiers", "aliases", "facts"},
        {"id", "kind", "name", "status", "provenance", "identifiers", "aliases", "facts"},
    )
    if e.get("schema_version", "1") != "1":
        _fail()
    _id(e["id"])
    _text(e["name"], 300)
    _choice(e["kind"], {"country", "region", "province", "municipality", "organization", "office"})
    _choice(e["status"], {"active", "retired"})
    _provenance(e["provenance"])
    for alias in _list(e["aliases"], 500):
        _text(alias, 300)
    for item in _list(e["identifiers"], 100):
        i = _record(
            item,
            {"entity_id", "scheme", "value", "valid_from", "valid_to", "provenance"},
            {"scheme", "value", "provenance"},
        )
        scheme = _choice(i["scheme"], PATTERNS)
        if (
            not re.fullmatch(PATTERNS[scheme], _text(i["value"], 64))
            or i.get("entity_id", e["id"]) != e["id"]
        ):
            _fail()
        _interval(i.get("valid_from"), i.get("valid_to"))
        _provenance(i["provenance"])
    for item in _list(e["facts"], 1000):
        f = _record(
            item,
            {"id", "entity_id", "predicate", "value", "valid_from", "valid_to", "provenance"},
            {"id", "predicate", "value", "provenance"},
        )
        _text(f["id"], 128)
        _choice(f["predicate"], PREDICATES)
        if type(f["value"]) not in {str, int, bool} or f.get("entity_id", e["id"]) != e["id"]:
            _fail()
        if isinstance(f["value"], str):
            _text(f["value"])
        if f["predicate"] == "website":
            _url(f["value"])
        if f["predicate"] == "population" and (type(f["value"]) is not int or f["value"] < 0):
            _fail()
        _interval(f.get("valid_from"), f.get("valid_to"))
        _provenance(f["provenance"])
    return e


class GovCoreClient:
    def __init__(self, base_url: str, *, timeout: float = 5.0, transport=None, max_bytes: int = 1_048_576):
        url = urlsplit(base_url)
        if (
            url.username
            or url.password
            or url.query
            or url.fragment
            or url.path not in {"", "/"}
            or not (
                url.scheme == "https"
                or url.scheme == "http"
                and url.hostname in {"localhost", "127.0.0.1", "::1"}
            )
            or not url.hostname
            or not 0 < timeout <= 10
            or not 1 <= max_bytes <= 1_048_576
        ):
            raise ValueError("GovCore requires HTTPS or local HTTP and bounded reads")
        self._timeout, self._max_bytes = timeout, max_bytes
        self._client = httpx.Client(
            base_url=base_url, timeout=timeout, follow_redirects=False, trust_env=False, transport=transport
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _get(self, path: str, params=None):
        start = time.monotonic()
        self._client.cookies.clear()
        try:
            with self._client.stream(
                "GET", path, params=params, headers={"Accept": "application/json"}
            ) as response:
                if (
                    response.status_code != 200
                    or "application/json" not in response.headers.get("content-type", "").lower()
                ):
                    raise GovCoreUnavailable("Public GovCore data unavailable")
                content = bytearray()
                for block in response.iter_bytes():
                    if time.monotonic() - start > self._timeout:
                        raise GovCoreUnavailable("Public GovCore read timed out")
                    content.extend(block)
                    if len(content) > self._max_bytes:
                        _fail()
                return json.loads(content, object_pairs_hook=_json_object)
        except httpx.HTTPError:
            raise GovCoreUnavailable("Public GovCore data unavailable") from None
        except (json.JSONDecodeError, UnicodeDecodeError, RecursionError):
            raise GovCoreContractError("Invalid public GovCore response") from None
        finally:
            self._client.cookies.clear()

    def resolve(
        self, *, istat_code: str | None = None, ipa_code: str | None = None, tax_code: str | None = None
    ) -> dict[str, object]:
        params = {
            k: v
            for k, v in {"istat_code": istat_code, "ipa_code": ipa_code, "tax_code": tax_code}.items()
            if v is not None
        }
        if not params:
            raise ValueError("Explicit public identifier required")
        for key, value in params.items():
            if not isinstance(value, str) or not re.fullmatch(
                PATTERNS[key.replace("_code", "") if key != "tax_code" else key], value
            ):
                raise ValueError("Invalid public identifier")
        if "ipa_code" in params:
            params["ipa_code"] = params["ipa_code"].casefold()
        result = _record(
            self._get("/v1/entities/resolve", params), {"schema_version", "status", "entity", "candidates"}
        )
        _choice(result["status"], {"resolved", "ambiguous", "not_found", "conflict"})
        if result["schema_version"] != "1":
            _fail()
        candidates = _list(result["candidates"], 100)
        for item in candidates:
            parse_entity(item)
        if result["status"] == "resolved":
            entity = parse_entity(result["entity"])
            if candidates or entity["status"] != "active":
                _fail()
            for key, value in params.items():
                scheme = {"istat_code": "istat", "ipa_code": "ipa", "tax_code": "tax_code"}[key]
                at = datetime.now(UTC)
                if not any(
                    i["scheme"] == scheme
                    and i["value"] == value
                    and _current(i.get("valid_from"), i.get("valid_to"), at)
                    and any(
                        proof["verification_status"] == "verified"
                        and _current(proof["valid_from"], proof["valid_to"], at)
                        for proof in i["provenance"]
                    )
                    for i in entity["identifiers"]
                ):
                    _fail()
        elif result["entity"] is not None:
            _fail()
        return result

    def get_entity(self, gov_entity_id: str) -> dict[str, object]:
        _id(gov_entity_id)
        response = self._get(f"/v1/entities/{gov_entity_id}")
        if not isinstance(response, dict) or response.get("schema_version") != "1":
            _fail()
        result = parse_entity(response)
        if result["id"] != gov_entity_id:
            _fail()
        return result

    def relationships(self, gov_entity_id: str) -> list[dict[str, object]]:
        _id(gov_entity_id)
        result = _record(
            self._get(f"/v1/entities/{gov_entity_id}/relationships"), {"schema_version", "items"}
        )
        if result["schema_version"] != "1":
            _fail()
        for item in _list(result["items"], 1000):
            r = _record(item, {"subject_id", "relation", "object_id", "valid_from", "valid_to", "provenance"})
            _choice(r["relation"], {"LOCATED_IN", "PART_OF", "SUCCESSOR_OF"})
            if _id(r["subject_id"]) != gov_entity_id:
                _fail()
            _id(r["object_id"])
            _interval(r["valid_from"], r["valid_to"])
            _provenance(r["provenance"])
        return result["items"]
