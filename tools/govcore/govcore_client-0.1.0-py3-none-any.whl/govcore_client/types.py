# SPDX-License-Identifier: MIT
# Copyright (c) 2026 metaforismo
"""Public read projections; these records never confer routing or action authority."""

from typing import Literal, TypedDict


class Page[T](TypedDict):
    schema_version: Literal["1"]
    items: list[T]
    total: int
    limit: int
    offset: int


class MunicipalIpaGap(TypedDict):
    id: str
    name: str
    istat_code: str | None


class EntityKindCounts(TypedDict):
    country: int
    region: int
    province: int
    municipality: int
    organization: int
    office: int


class ContactStatusCounts(TypedDict):
    listed: int
    pending: int
    verified: int
    revoked: int
    suspended: int


class SourceStatusCounts(TypedDict):
    active: int
    revoked: int
    suspended: int


class EntityCounts(TypedDict):
    total: int
    active: int
    by_kind: EntityKindCounts


class IdentifierCounts(TypedDict):
    total: int
    active_municipalities_with_current_istat: int
    active_municipalities_with_current_istat_and_ipa: int


class ContactCounts(TypedDict):
    total: int
    by_status: ContactStatusCounts
    stored_verified_reviews_due: int


class SourceCounts(TypedDict):
    total: int
    by_status: SourceStatusCounts
    never_acquired: int
    active_refresh_due: int
    latest_retrieval: str | None


class CoverageSnapshot(TypedDict):
    schema_version: Literal["1"]
    as_of: str
    scope: Literal["registered_public_records"]
    entities: EntityCounts
    identifiers: IdentifierCounts
    contacts: ContactCounts
    sources: SourceCounts
